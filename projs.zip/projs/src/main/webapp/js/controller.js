app.controller('CustomerController', function($scope) {
    $scope.headingTitle = "Customer List";
});

app.controller('rolesController', function($scope) {
    $scope.headingTitle = "Roles List";
});

