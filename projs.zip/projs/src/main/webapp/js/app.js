var takealotModule = angular.module("takealotApp",["ngRoute","ngStorage"]);
takealotModule.config(["$routeProvider","$locationProvider",function($routeProvider,$locationProvider) {
    $routeProvider
       $locationProvider.hashPrefix('');
      $routeProvider
      .when('/', {   
       templateUrl :'/',
        controller : 'CustomerController'
   })
     .when('/login', {   
       templateUrl :'/login',
        controller : 'CustomerController'
   })   
     .when('/product',{
       templateUrl :'/product',
        controller :'ProductController'
     })
     .when('/viewlist',{
       templateUrl :'/viewlist',
        controller :'ProductController'
     })  
     
     .when('/custview',{
       templateUrl :'/custview',
        controller :'ProductController'
     }) 
     
     .when('/payment',{
       templateUrl :'/payment',
        controller :'PaymentController'
     })     
      .when('/index',{
       templateUrl :'/index',
        controller :'CustomerController'
     }) 
      .when('/aregister',{
       templateUrl :'/aregister',
        controller :'AdminController'
     })  
      .when('/admin',{
       templateUrl :'/admin',
        controller :'AdminController'
     }) 
      .when('/account',{
       templateUrl :'/account',
        controller :'PaymentController'
       
     }) 
      .when('/Order',{
       templateUrl :'/Order',
        controller :'CustomersOrderController'
       
     }) 
       .when('/vieworder',{
       templateUrl :'/vieworder',
        controller :'CustomersOrderController'
       
     }) 
      .when('/viewPayments',{
       templateUrl :'/viewPayments',
        controller :'PaymentController'
       
     })     
   .otherwise({
       redirectTo :'home'
    });
    
    
}]);



takealotModule.controller("AdminController",['$scope','$http',function($scope,$http){
   // $http.defaults.headers.post["Content-Type"] = "application/json";  
          
        $scope.createAdmin = function ()
        {
            var user = {
                        "fname" :$scope.fname,
                        "lname" :$scope.lname,
                        "email" : $scope.email,
                        "password" : $scope.password,
                        "mobileNo" : $scope.mobileNo
                         
                        
                    };
                    console.log(user);
                     $http.post('/admin/aregister',user        
		        ).then(
		        		
		                function(response){
		                    $scope.da =response.data;
		                   alert("Data inserted");
		                } 
		    );
        };
        
        $scope.admins=[];
        $scope.Admlogin = function(){
        	$http.get('/user/admin')
                .then(
                             function(response) {
                          	   $scope.admins = response.data;
                          	   console.log($scope.admins);
                                 for(var i=0;i<$scope.admins.length;i++)
                                 {
                              	   if($scope.admins[i].password ===  $scope.password && $scope.admins[i].email ===  $scope.email)
                              		   {
                              		 $scope.em = $scope.email;
                              		 alert("Welcome " + $scope.email);
                              		 
                              		   }
                              	   else
                              		   {
                              		   console.log("Invalid user name/password");
                              		   }
                                 }
                             
                                 window.location = '/product';
                                 
                             }
                             ,
                              function(errResponse){
                                  console.error('Error while fetching Currencies');
                              }
                     );
        };       
}]);




takealotModule.controller("PaymentController",['$scope','$http',function($scope,$http){
  $http.defaults.headers.post["Content-Type"] = "application/json";  
    var Data = {};
    window.location.search.replace(/\?/,'').split('&').map(function(o){ Data[o.split('=')[0]]= o.split('=')[1];});
    var userId = Data.id; 
    
          $http.get('http://localhost:8080/details/view').then
          (function(response){$scope.details = response.data;});
    
    
        $scope.AddAcount = function ()
        {
            var user = {
                        "cardNum" :$scope.cardNum,
                        "bank" :$scope.bank,
                        "balance" :$scope.balance

                        
                    };
                    console.log(user);
                     $http.post('/payment/save',user        
		        ).then(
		        		
		                function(response){
		                    $scope.da =response.data;
		                   alert("Account saved");
		                } 
		    );
        };
   
        
        $scope.payments=[];
$scope.Pay = function(){
                        
            var payDetails = {
                        "payDate" :$scope.payDate,
                        "bank" :$scope.bank,
                        "address":$scope.address,
                        "cardHolder" : $scope.cardHolder,
                        "customerId" : userId
                        
                    };
        	$http.get('/user/payments')
                .then( function(response) {
                          	   $scope.payments = response.data;
                          	   console.log($scope.payments);
                                 for(var i=0;i<$scope.payments.length;i++)
                                 {
                              	   if($scope.payments[i].cardNum === $scope.cardNum && $scope.payments[i].bank === $scope.bank)
                              		   {
                              		 $scope.cn = $scope.cardNum;
                              		 alert("Payment succeded");
                                         window.location = '/';
                              		 
                              		   }

                                 }

                                 
                             }
                             ,
                              function(errResponse){
                                  console.error('Card number does not exist');
                                  
                              }
                     );

             
             
                    console.log(payDetails);
                     $http.post('/datails/add',payDetails        
		        ).then(
		        		
		                function(response){
		                    $scope.da =response.data;
		                   
		                } 
		    );
             
   
          
              
   
          };
          
 
        

   
        
}]);        
takealotModule.controller("CustomerController",['$scope','$http',function($scope,$http){
   // $http.defaults.headers.post["Content-Type"] = "application/json";  
          
        $scope.create = function ()
        {
            var user = {
                        "fname" :$scope.fname,
                        "lname" :$scope.lname,
                        "email" : $scope.email,
                        "password" : $scope.password,
                        "mobileNo" : $scope.mobileNo,
                         
                         "id" : $scope.id
                        
                    };
                    console.log(user);
                    
                     $http.post('/customer/register',user        
		        ).then(
		        		
		                function(response){
		                    $scope.da =response.data;
		                   alert("You are now registered");
		                } 
		    );
        };
        

        $scope.customers=[];
        
        $scope.login = function(){
            var custid = $scope.id;
            var name = $scope.fname;
        	$http.get('/user/customers')
                .then(
                             function(response) {
                          	   $scope.customers = response.data;
                          	   console.log($scope.customers);
                                  
                                 for(var i=0;i<$scope.customers.length;i++)
                                 {
                              	   if($scope.customers[i].password ===  $scope.password && $scope.customers[i].email ===  $scope.email)
                              		   {
                                            
                                         custid = $scope.customers[i].id; 
                              		  $scope.em = $scope.email;
                                         
                              		  alert("Welcome " + $scope.email);
                                          window.location = './custview.html?id=' + custid;
                              		   }
                              	   else
                              		   {
                              		   console.log("Invalid user name/password");
                              		   }
                                 }
                              
                                 
                           
                             }
                             ,
                              function(errResponse){
                                  console.error('Error while fetching Currencies');
                              }
                     );
        };

        
}]);



takealotModule.controller("CustomersOrderController",['$scope','$http',function($scope,$http){
   $http.defaults.headers.post["Content-Type"] = "application/json";
   
    var Data = {};
    window.location.search.replace(/\?/,'').split('&').map(function(o){ Data[o.split('=')[0]]= o.split('=')[1];});
    var userId = Data.id;  
    $scope.cartData = [];
    $scope.Proceed = function()
    {
       for(var x = 0; x < $scope.cartData.length; x++){
           

          var quantity = $scope.cartData[x].quantity;
          var productid = $scope.cartData[x].productid;
          var price =  $scope.cartData[x].price;
          var category = $scope.cartData[x].category;
          
          var orderData = {
              "customerName" : $scope.customerName,
              "orderTotal" : $scope.cardAmount,
              "Date" : $scope.Date,
              "productID" : productid,
              "price" : price,
              "quantity" :quantity,
              "cartegory" : category,
              "customerId" : userId 
            
              
          };
           console.log(orderData);  
                     $http.post('/order/save',orderData        
		        ).then(
		        		
		                function(response){
		                    $scope.da =response.data;
		                   alert("order is been processed");
		                } 
		    );           

   
          }
          
          
         
        
           
       };
  
      
}]);   
//////*********************************Cart***************************************
takealotModule.controller("ShoppingCartController",['$scope','$http',function($scope,$http){
   $http.defaults.headers.post["Content-Type"] = "application/json"; 
   
    $http.get('http://localhost:8080/product/view').then
          (function(response){$scope.products = response.data;});
          
          
   $scope.cartData = [];
    var qt = 0;
    var c = 0;
   //$scope.cardAmount = 0.0;
   
   var amount = 0.0;
   var totalQuantity = 0;
   
   $scope.addToCart = function(product,quantity)
    {
        
    
        var checkedItem = checkCartData(product.productID);
        
        
        product.quantity = quantity;
        product.price = product.price * product.quantity;
        if(checkedItem === null)
        {
            $scope.cartData.push({
                    "productID" :product.productID,
                    "quantity" : product.quantity,
                    "name": product.pname,
                    "price":product.price}
                        
                );
         }else{
            checkCartData.quantity++;
        }
 
            if($scope.cartData.length !== 0)
            {
                
              amount = parseFloat(amount + $scope.cartData[c].price);
              totalQuantity = totalQuantity + $scope.cartData[c].quantity;
             c++;
             
          }
              
        $scope.cardAmount = amount; 
        $scope.quantityTotal = totalQuantity;
       
            
        function checkCartData(pid)
        {
            for (var i=0; i< $scope.cartData.length; i++)
            {
               if($scope.cartData[i].productID === pid)
              {
                 return $scope.cartData[i];
              }
            }

            return null;
        };
 


  


    };
   $scope.ContinueShop = function()
    {         
       for(var x = 0; x < $scope.cartData.length; x++){
           

          var totQuantity = $scope.quantityTotal;
          var productId = $scope.cardData[x].productID;
          var totPrice = $scope.cardAmount;

          
          var Cart = {
              "productID" : productId,
              "price" : totPrice,
              "quantity" : totQuantity
   
              
          };
          
                                                                
          
        }  
    };        
//*************************************ContinueShop******************************************
      
       $scope.ContinueShop = function ()
       {
                
                var Data = {};
                window.location.search.replace(/\?/,'').split('&').map(function(o){ Data[o.split('=')[0]]= o.split('=')[1];});
                var userId = Data.id;
                var nam = Data.fname;
                var totalorder = $scope.cardAmount;
                var zero = 00;
                 var minNumber = 0; // The minimum number you want
                 var maxNumber = 500; // The maximum number you want
                 var randomnumber = Math.floor(Math.random() * (maxNumber + 1) + minNumber);
                 var orderno = zero + randomnumber;  
              
                   
                   
                   
                
                 
                
                //$scope.cartData = [];
                
        var orderData = {
              "customerId" : userId,
              "orderTotal" : totalorder,
              "customerName" : nam,
              "orderNumber" : orderno
              
          };
          console.log(orderData);  
                     $http.post('/order/save',orderData        
		        ).then(
		        		
		                function(response){
		                    $scope.da =response.data;
		                  
		                } 
		    );          


             window.location = '/payment.html?id=' + userId;
             
             
             
            
            
       };
       
//**************************************get Total***********************************************
       $scope.Cart = function ()
       {
         
           var amount = 0.0;
           for(var c = 0; c < $scope.cartData.length; c++)
            {
                
              amount = parseFloat(amount + $scope.cartData[c].price);
             
              //$scope.cartData[c].quantity++;
              
             
             }
             
            $scope.cardAmount = amount;
            
       };        
            
}]);

takealotModule.controller("CustomersOrderController",['$scope','$http',function($scope,$http){
   $http.defaults.headers.post["Content-Type"] = "application/json";  
 
        
          $http.get('http://localhost:8080/order/view').then
          (function(response){$scope.orders = response.data;});
          
          
        $scope.deleteOrder = function (id)
        {
            
            console.log(id);
            
            $http.delete('http://localhost:8080/order/delete/' + id + '').then(function(response){
                console.log(response);
                alert("Product has been Deleted");
             });
        };         
          
}]);
//////*********************************Adding  product***************************************

takealotModule.controller("ProductController",['$scope','$http',function($scope,$http){
   $http.defaults.headers.post["Content-Type"] = "application/json";  
 
        
          $http.get('http://localhost:8080/product/view').then
          (function(response){$scope.products = response.data;});
          
          
          
        
        $scope.deletePro = function (id)
        {
            
            console.log(id);
            
            $http.delete('http://localhost:8080/product/delete/' + id + '').then(function(response){
                console.log(response);
                alert("Product has been Deleted");
             });
        };       

           
}]);

//*********************************Adding  product***************************************

takealotModule.controller("AddProductController",['$scope','$http',function($scope,$http){
   $http.defaults.headers.post["Content-Type"] = "application/json";  
  
           $scope.image = null;
            var imageCopy = null;
            var image = null;
		    var handleImageSelect = function (evt)
		    {
		        var files = evt.target.files;
		        var file = files[0];

		        if (files && file) {
		           
		            var reader = new FileReader();
		            reader.onload = function (readerEvt) {
		                var binaryString = readerEvt.target.result;
		                imageCopy = btoa(binaryString);
		                image = 'data:image/octet-stream;base64,' + imageCopy;
		                $scope.image = image;
		             };

		            reader.readAsBinaryString(file);
		        }
		    };

		    if (window.File && window.FileReader && window.FileList && window.Blob) {
		        document.getElementById('productImage').addEventListener('change', handleImageSelect, false);
		    } else {
		        alert('The File APIs are not fully supported in this browser.');
		    } 
      $scope.addProd = function ()
        {
            var product = {
                         "pname" : $scope.pname,
                         "catergory" : $scope.catergory,
                         "price" : $scope.price,
                         "image":$scope.image
        };
               console.log(product);
                    $http.post('http://localhost:8080/product/add',product        
		        ).then(

		                function(response){
		                    $scope.da =response.data;
		                   alert("Data inserted");
                                   
                                   
		                } 
		    );
   
        };
        

}]);

//**************************************save order************************************************************************




