/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author User
 */
@Entity
@Table(name = "Account")
public class Payment {




    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long customerID;
    private String cardNum;
    private String bank;
    //private double balance;
    
    
    public Payment()
    {
        
    }
    
    
   public Payment(Long customerID,String cardNum,String bank)
    {
       this.bank = bank;
       this.cardNum = cardNum;
       this.customerID = customerID;
       //this.balance = balance;
       
       
    }
   
      /**
     * @return the customerID
     */
    public Long getCustomerID() {
        return customerID;
    }

    /**
     * @param customerID the customerID to set
     */
    public void setCustomerID(Long customerID) {
        this.customerID = customerID;
    }

    /**
     * @return the cardNum
     */
    public String getCardNum() {
        return cardNum;
    }

    /**
     * @param cardNum the cardNum to set
     */
    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

 


    /**
     * @return the bank
     */
    public String getBank() {
        return bank;
    }

    /**
     * @param bank the bank to set
     */
    public void setBank(String bank) {
        this.bank = bank;
    } 
    
    /**
     * @return the balance
     */
   /* public double getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
   /* public void setBalance(double balance) {
        this.balance = balance;
    }*/    
    
}
