/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.service;

import com.take.lot.Takelot.entities.ShoppingCart;
import com.take.lot.Takelot.repository.ShoppinCartRep;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public class ShoppingCartService {
    
    @Autowired
    public ShoppinCartRep repository;   
    
    public void SaveCart(ShoppingCart shocart)
    {
        ShoppingCart cart = new ShoppingCart();
        cart.setCartID(shocart.getCartID());
        cart.setPrice(shocart.getPrice());
        cart.setProductID(shocart.getProductID());
        cart.setQuantity(shocart.getQuantity());
        repository.save(cart);
    }
    
    public ArrayList<ShoppingCart> getAllCartItem(Long id)
    {
        ArrayList<ShoppingCart> shocart = new ArrayList<>();
        repository.findAll().
        forEach(shocart::add);
        return shocart;
    }
    
    
    public void DeleteCart(Long cartID)
    {
        repository.delete(cartID);
    }
    
    
}
