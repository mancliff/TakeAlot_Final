/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.controller;

import com.take.lot.Takelot.entities.CustomersOrder;
import com.take.lot.Takelot.service.CustomersOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author User
 */
@Controller
public class CustomersOrderController {
    
          @Autowired
    private CustomersOrderService service;
    
   
   
   @RequestMapping(value = "/order/save", method = RequestMethod.POST)
   @ResponseBody
    public CustomersOrder saveOrder(@RequestBody CustomersOrder order){
    	
        
        CustomersOrder ord = service.save(order);
        return ord;
    }
    
    @RequestMapping(value = "/order/view", method = RequestMethod.GET)
    @ResponseBody
    public Object getOrders(){
        
      return service.getAll();
    }
    @RequestMapping(value = "/order/delete/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public void DeleteOrder(@PathVariable Long id)
    {
       service.deleteOrderBYid(id);
    }    
    
    
}
