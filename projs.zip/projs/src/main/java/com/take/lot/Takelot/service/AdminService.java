/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.service;

import com.take.lot.Takelot.entities.Admin;
import com.take.lot.Takelot.repository.AdminRep;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public class AdminService {
    
    
    @Autowired
    private AdminRep repository;
    

    private static List<Admin> admins;
    
    public Object getAll()
    {
        return repository.findAll();
    }
    public Admin findById(Long id){
    
        return repository.findOne(id);
    } 

    public void save(Admin admin)
    {
    	Admin Ad = new Admin();
    	Ad.setId(admin.getId());
    	Ad.setFname(admin.getFname());
    	Ad.setLname(admin.getLname());
    	Ad.setMobileNo(admin.getMobileNo());
    	Ad.setEmail(admin.getEmail());
    	Ad.setPassword(admin.getPassword());
        
        repository.save(Ad);
        return;
    } 
    
   public List<Admin> findAllAdmins()
   {

       admins = new ArrayList<>();
       
       repository.findAll().forEach(admins::add);
       
      
       return admins; 
   }    
    
    public Admin saveData(Admin ad) {
      return repository.save(ad); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public void delete(Admin ad){
    
        repository.delete(ad);
        return;
    }
    public Admin findByEmail(String email){
    
      return null;
    }  
}
