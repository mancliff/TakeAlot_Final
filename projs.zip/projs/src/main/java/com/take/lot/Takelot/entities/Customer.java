/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.entities;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;
import org.springframework.data.annotation.Transient;



@Entity
@Table(name = "Customer")
public class Customer  {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
private Long id;
private String fname;
private String lname;
private String email;

@Transient
private String password;
private String mobileNo;

public Customer()
{
	
}

public Customer(String mobileNo,String password,String email,String lname, String fname, Long id)
{
	this.id = id;
	this.email = email;
	this.fname = fname;
	this.lname = lname;
        
	this.mobileNo = mobileNo;
	this.password = password;
}

public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}
        

        

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

    private String Date() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
