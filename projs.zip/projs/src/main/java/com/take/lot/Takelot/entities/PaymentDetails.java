/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author User
 */
@Entity
@Table(name = "PaymentDetails")
public class PaymentDetails {




        @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
private Long payID;
private Long customerId;        
private String cardHolder;
private String address;
private String payDate; 
private String bank;

public PaymentDetails()
{}

    public PaymentDetails(Long payID,Long customerId, String cardHolder,String bank,String payDate,String address) {
        this.payID = payID;
        this.cardHolder = cardHolder;
        this.customerId = customerId;
    }

    public Long getPayID() {
        return payID;
    }

    public void setPayID(Long payID) {
        this.payID = payID;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }
    
        /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the payDate
     */
    public String getPayDate() {
        return payDate;
    }

    /**
     * @param payDate the payDate to set
     */
    public void setPayDate(String payDate) {
        this.payDate = payDate;
    }
        /**
     * @return the customerId
     */
    public Long getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
    
}
