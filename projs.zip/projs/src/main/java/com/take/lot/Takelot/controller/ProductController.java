/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.controller;


import com.take.lot.Takelot.entities.Product;
import com.take.lot.Takelot.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author User
 */
@Controller
public class ProductController {
    
   @Autowired
    private ProductService service;
    
   
   
   @RequestMapping(value = "/product/add", method = RequestMethod.POST)
   @ResponseBody
    public Product SaveProduct(@RequestBody Product product){
    	
        
        Product prod = service.save(product);
        if(prod != null)
        {
            System.out.println("Not Empty");
        }else
        {
            System.out.println(" Empty");
        }
        return prod;
    }  
    
    @RequestMapping(value = "/product/view", method = RequestMethod.GET)
    @ResponseBody
    public Object getProducts(){
        
      return service.getAll();
    }
    
    @RequestMapping(value = "/product/delete/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public void DeleteProduct(@PathVariable Long id)
    {
       service.deleteProBYid(id);
    }
    
}
    
