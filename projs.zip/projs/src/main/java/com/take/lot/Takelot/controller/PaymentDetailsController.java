/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.controller;


//import com.take.lot.Takelot.entities.PaymentDetails;
import com.take.lot.Takelot.entities.PaymentDetails;
import com.take.lot.Takelot.service.PaymentDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author User
 */
@Controller
public class PaymentDetailsController {
    
@Autowired
    private PaymentDetailsService service;
    
   
   
   @RequestMapping(value = "/datails/add", method = RequestMethod.POST)
   @ResponseBody
    public PaymentDetails SavePayment(@RequestBody PaymentDetails detail){
    	
        
        return  service.save(detail);
    }  
    @RequestMapping(value = "/details/view", method = RequestMethod.GET)
    @ResponseBody
    public Object getPayments(){
        return service.getAll();
    }
    
    /*@RequestMapping(value = "/datails/view", method = RequestMethod.GET)
    @ResponseBody
    public Object getPayments(){
        
      return service.getAll();
    }
   
    @RequestMapping(value = "/datails/delete/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public void DeletePayments(@PathVariable Long id)
    {
       service.deleteProBYid(id);
    }    

    private static class PaymentDetails {

        public PaymentDetails() {
        }
    }*/
    
}
