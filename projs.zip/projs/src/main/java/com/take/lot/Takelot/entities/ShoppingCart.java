/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author User
 */
@Entity
@Table(name = "ShoppingCard")
public class ShoppingCart {




     @Id
    @GeneratedValue(strategy = GenerationType.AUTO) 
     
     private Long cartID;
     private Long productID;
     private double price;
     private int quantity;
     
     
     public ShoppingCart()
     {
     }
     
     public ShoppingCart(Long cartID,Long productID,double price,int quantity)
     {
         
         this.cartID = cartID;
         this.productID = productID;
         this.price = price;
         this.quantity = quantity;
     }

    /**
     * @return the cartID
     */
    public Long getCartID() {
        return cartID;
    }

    /**
     * @param cartID the cartID to set
     */
    public void setCartID(Long cartID) {
        this.cartID = cartID;
    }

    /**
     * @return the productID
     */
    public Long getProductID() {
        return productID;
    }

    /**
     * @param productID the productID to set
     */
    public void setProductID(Long productID) {
        this.productID = productID;
    }

    /**
     * @return the quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    } 
    /**
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }    
     
}
