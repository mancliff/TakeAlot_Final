/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import org.hibernate.validator.constraints.Length;


/**
 *
 * @author User
 */

@Entity
@Table(name = "Product")
public class Product  implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "productID")
    private Long productID;
    @Column(name = "pname")
    private String pname;
    @Column(name = "cartegory")
    private String cartegory;
    @Column(name = "price")
    private Double price;
    
    @Column(name = "image")
    private String image;
 
   
    
    public Product(){
    }
    
    
    public Product(Long productID,String pname,String catergory,Double price,String image){
        
       this.cartegory = catergory;
       this.pname = pname;
       this.price = price;
       this.productID = productID;
       this.image = image;
    } 
 
    /**
     * @return the productID
     */
    public Long getProductID() {
        return productID;
    }

    /**
     * @param productID the productID to set
     */
    public void setProductID(Long productID) {
        this.productID = productID;
    }

    /**
     * @return the pname
     */
    public String getPname() {
        return pname;
    }

    /**
     * @param pname the pname to set
     */
    public void setPname(String pname) {
        this.pname = pname;
    }

    /**
     * @return the catergory
     */
    public String getCatergory() {
        return cartegory;
    }

    /**
     * @param catergory the catergory to set
     */
    public void setCatergory(String catergory) {
        this.cartegory = catergory;
    }

    /**
     * @return the price
     */
    public Double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(Double price) {
        this.price = price;
    }
        /**
     * @return the image
     */
    public String getImage() {
        return image;
    }

    /**
     * @param image the image to set
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * @return the image
     */  

    
}
