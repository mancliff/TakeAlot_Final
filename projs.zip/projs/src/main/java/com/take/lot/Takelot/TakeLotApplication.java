package com.take.lot.Takelot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TakeLotApplication {

	public static void main(String[] args) {
		SpringApplication.run(TakeLotApplication.class, args);
	}
}
