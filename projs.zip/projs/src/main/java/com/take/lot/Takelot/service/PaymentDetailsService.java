/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.service;


import com.take.lot.Takelot.entities.PaymentDetails;
import com.take.lot.Takelot.repository.PaymentDetailsRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public class PaymentDetailsService {

    @Autowired
    private PaymentDetailsRepository repository; 
    
    private static List<PaymentDetails> details;
    public Object getAll()
    {
        return repository.findAll();
    } 
    
    public PaymentDetails findById(Long id){
    
        return repository.findOne(id);
    }
    
   public List<PaymentDetails> findAllPayments()
   {

       details = new ArrayList<>();
       
       repository.findAll().forEach(details::add);
       
      
       return details; 
   } 
   
    public PaymentDetails save(PaymentDetails detail)
    {
        PaymentDetails det = new PaymentDetails();
        det.setCustomerId(detail.getCustomerId());
        det.setBank(detail.getBank());
        det.setCardHolder(detail.getCardHolder());
        det.setAddress(detail.getAddress());
        det.setPayDate(detail.getPayDate());
        
        return repository.save(det);
    }
    
   public void deletePayments(PaymentDetails det){
   
    repository.delete(det);
   } 
    
   public void deletePaymentsBYid(Long id)
   {
      repository.delete(id);
   }   

    public void deleteProBYid(Long id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
