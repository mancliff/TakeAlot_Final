/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.service;



import com.take.lot.Takelot.entities.Product;
import com.take.lot.Takelot.repository.ProductRep;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public class ProductService {
    
        @Autowired
    private ProductRep repository;
    

    private static List<Product> products;
    public Object getAll()
    {
        return repository.findAll();
    }
    public Object CustView()
    {
        return repository.findAll();
    }
    public Product findById(Long id){
    
        return repository.findOne(id);
    }        
    public Product save(Product product)
    {
        Product pro = new Product();
        pro.setCatergory(product.getCatergory());
        pro.setPrice(product.getPrice());
        pro.setProductID(product.getProductID());
        pro.setPname(product.getPname());
        pro.setImage(product.getImage());
        return repository.save(pro);
    }
    
   public void deleteP(Product prod){
   
    repository.delete(prod);
   } 
    
   public void deleteProBYid(Long id)
   {
      repository.delete(id);
   }
   public List<Product> findAllProducts()
   {

       products = new ArrayList<>();
       
       repository.findAll().forEach(products::add);
       
      
       return products; 
   }

    public Product saveData(Product prod) {
      return repository.save(prod); //To change body of generated methods, choose Tools | Templates.
    }
 
   
}
