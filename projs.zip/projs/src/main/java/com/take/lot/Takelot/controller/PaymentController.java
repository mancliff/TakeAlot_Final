/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.controller;

import com.take.lot.Takelot.entities.Payment;
import com.take.lot.Takelot.service.PaymentService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
public class PaymentController {
      @Autowired
    private PaymentService service;
    
   
   
   @RequestMapping(value = "/payment/save", method = RequestMethod.POST)
   @ResponseBody
    public Payment SavePayt(@RequestBody Payment payment){
    	
        
        Payment pay = service.save(payment);
        return pay;
        
     
    }
    @Autowired
    private PaymentService payService;
    private List<Payment> payments;

    @RequestMapping(method = RequestMethod.GET, value = "/user/payments")
    public List<Payment> getAll()
    {
        payments = new ArrayList<>();
        payService.findAllPayments().forEach(payments::add);
        return payments;
    }    
}
