/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.service;

import com.take.lot.Takelot.entities.Customer;
import com.take.lot.Takelot.repository.CustomerRep;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public class CustomerService  {
    
    @Autowired
    private CustomerRep repository;
    

    private static List<Customer> customers;
    
    public Object getAll()
    {
        return repository.findAll();
    }
    public Customer findById(Long id){
    
        return repository.findOne(id);
    }
    
    public void save(Customer customer)
    {
    	Customer cust = new Customer();
    	cust.setId(customer.getId());
    	cust.setFname(customer.getFname());
    	cust.setLname(customer.getLname());
    	cust.setMobileNo(customer.getMobileNo());
    	cust.setEmail(customer.getEmail());
    	cust.setPassword(customer.getPassword());
       
        repository.save(cust);
        return;
    }
    
   

   public List<Customer> findAllCustomers()
   {

       customers = new ArrayList<>();
       
       repository.findAll().forEach(customers::add);
       
      
       return customers; 
   }

    
    public Customer saveData(Customer cust) {
      return repository.save(cust); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public void delete(Customer Cust){
    
        repository.delete(Cust);
        return;
    }
    public Customer findByEmail(String email)
    {
        Customer cust = new Customer();
        cust = repository.findByEmail(email);
        return cust;
    }
}
