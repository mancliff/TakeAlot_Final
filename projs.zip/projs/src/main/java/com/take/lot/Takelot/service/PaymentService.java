/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.service;

import com.take.lot.Takelot.entities.Payment;
import com.take.lot.Takelot.repository.PaymentRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 *
 * @author User
 */
@Service
public class PaymentService {
    
    @Autowired
    private PaymentRepository repository;
    private static List<Payment> payments;
    public Object getAll()
    {
        return repository.findAll();
    }    
       
    public Payment save(Payment payment)
    {
        Payment pay = new Payment();
        pay.setBank(payment.getBank());
        pay.setCardNum(payment.getCardNum());
        pay.setCustomerID(payment.getCustomerID());
        //pay.setBalance(payment.getBalance());
        return repository.save(pay);
    }       
    
 
  public List<Payment> findAllPayments()
   {

       payments = new ArrayList<>();
       
       repository.findAll().forEach(payments::add);
       
      
       return payments; 
   }    
    
    
}
