/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author User
 */
@Controller
public class ViewController {
        

    @RequestMapping("/")
    String home(ModelMap modal) {
        modal.addAttribute("title","home");
        return "home";
    }
    
    
    @RequestMapping(value="/login", method = RequestMethod.GET)
    String login() 
    {
        return "login";
    }
    
    @RequestMapping(value="/test", method = RequestMethod.GET)
    String inde() 
    {
        return "test";
    }
    
    @RequestMapping(value="/index")
    String home() 
    {
        return "index";
    }    
    
    @RequestMapping(value="/product")
    String product() 
    {
        return "product";
    }
   @RequestMapping(value="/viewlist")
    String viewlist() 
    {
        return "viewlist";
    }
    
    
    @RequestMapping(value="/custview")
    String custview() 
    {
        return "custview";
    }  
    
       
    @RequestMapping(value="/saveCart")
    String saveCart() 
    {
        return "saveCart";
    } 
    @RequestMapping(value="/aregister")
    String aregister() 
    {
        return "aregister";
    }     
    @RequestMapping(value="/admin")
    String admin() 
    {
        return "admin";
    } 
    
    @RequestMapping(value="/payment")
    String payment() 
    {
        return "payment";
    } 
    @RequestMapping(value="/account")
    String account() 
    {
        return "account";
    } 
    @RequestMapping(value="/Order")
    String Order() 
    {
        return "Order";
    }  
    @RequestMapping(value="/vieworder")
    String vieworder() 
    {
        return "vieworder";
    }  
    @RequestMapping(value="/viewPayments")
    String viewPayments() 
    {
        return "viewPayments";
    }    
    
}
