/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.service;

import com.take.lot.Takelot.entities.CustomersOrder;
import com.take.lot.Takelot.repository.CustomersOrderRep;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public class CustomersOrderService {
  
    
    @Autowired
    private CustomersOrderRep repository; 
    
    private static List<CustomersOrder> orders;
    public Object getAll()
    {
        return repository.findAll();
    } 
    
    public CustomersOrder findById(Long id){
    
        return repository.findOne(id);
    }
    
   public List<CustomersOrder> findAllProducts()
   {

       orders = new ArrayList<>();
       
       repository.findAll().forEach(orders::add);
       
      
       return orders; 
   }    
    
   public CustomersOrder save(CustomersOrder order)
    {
        CustomersOrder ord = new CustomersOrder();
        ord.setCustomerId(order.getCustomerId());
       
        ord.setOrderTotal(order.getOrderTotal());
        ord.setOrderNumber(order.getOrderNumber());
       

        return repository.save(ord);
    }
   public void deleteOrderBYid(Long id)
   {
      repository.delete(id);
   }  
}
