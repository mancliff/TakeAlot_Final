/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.take.lot.Takelot.controller;

import com.take.lot.Takelot.entities.Customer;
import com.take.lot.Takelot.service.CustomerService;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
public class CustomerController {
    @Autowired
    private CustomerService service;
    
    
    @RequestMapping(value = "/customer/register", method = RequestMethod.POST)
    public Customer SaveCust(@RequestBody Customer customer){
    	service.save(customer);
    	return customer;
    	
    }
    

    
    
    @Autowired
    private CustomerService custService;
    private List<Customer> customers;

    @RequestMapping(method = RequestMethod.GET, value = "/user/customers")
    public List<Customer> getAll()
    {
        customers = new ArrayList<>();
        custService.findAllCustomers().forEach(customers::add);
        return customers;
    }
    
    @RequestMapping(value = "getCust/{email]", method = RequestMethod.GET)

    public Customer getCust(@PathVariable String email)
    {   
        Customer cust = new Customer();
        cust = custService.findByEmail(email);
        return cust;
    }
}
