


--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `Order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Order` (
  `orderNumber` int(11) NOT NULL AUTO_INCREMENT,
  `orderDate` varchar(255) NOT NULL,
  `customerName` varchar(255) NOT NULL,
  PRIMARY KEY (`orderNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;






--
-- Table structure for table `user_role`
--

